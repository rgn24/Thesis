class UnknownWritingError(Exception):
    """Raised when a writing error occurs"""
    pass